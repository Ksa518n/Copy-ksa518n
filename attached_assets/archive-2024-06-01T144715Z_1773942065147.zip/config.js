module.exports={
    parentId :'لوج',
    probot_ids :'بروبوت',
    recipientId : 'البنك',
    price : 'سعر بدون ضرايب',
    log : 'لوج'
}